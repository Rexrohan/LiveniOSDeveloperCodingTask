import Foundation
import XCTest

struct RestaurantMenu {
    let name: String
    let price: Double
    let quantity: Int
}

struct RestaurantReceipt {
    let groupNumber: Int
    var items: [RestaurantMenu]
    
    func calculateTotal() -> Double {
        return items.reduce(0) { $0 + ($1.price * Double($1.quantity)) }
    }
    
    func displayInvoice() {
        print("Group \(groupNumber) Bill:")
        for item in items {
            print("\(item.name) $\(item.price)x\(item.quantity)")
        }
    }
}

func paymentCalculation(for group: RestaurantReceipt, discount: Double = 0, creditCardPayment: Bool = false) -> (paid: Double, returned: Double, remaining: Double) {
    let totalAmount = group.calculateTotal()
    let discountAmount = totalAmount * discount
    let discountedTotal = totalAmount - discountAmount
    let taxes = discountedTotal * 0.1
    var surcharge = 0.0
    if creditCardPayment {
        surcharge = discountedTotal * 0.012
    }
    let finalAmount = discountedTotal + taxes + surcharge
    group.displayInvoice()
    print("Discount: $\(discountAmount)")
    print("Taxes: $\(taxes)")
    print("Surcharge: $\(surcharge)")
    print("Final Amount: $\(finalAmount)")
    let paid = finalAmount
    let returned = 0.0
    let remaining = 0.0
    print("\nPayment Details:")
    print("Paid $\(paid) by \(creditCardPayment ? "Credit Card" : "Cash")")
    return (paid, returned, remaining)
}

//:- UNIT TEST

class RestaurantTests: XCTestCase {
    func testHandlePayment() {
        let group1 = RestaurantReceipt(groupNumber: 1, items: [
            RestaurantMenu(name: "Big Brekkie", price: 16, quantity: 2),
            RestaurantMenu(name: "Bruchetta", price: 8, quantity: 1),
            RestaurantMenu(name: "Poached Eggs", price: 12, quantity: 1),
            RestaurantMenu(name: "Coffee", price: 5, quantity: 1),
            RestaurantMenu(name: "Tea", price: 3, quantity: 1),
            RestaurantMenu(name: "Soda", price: 4, quantity: 1)
        ])
        
        let group2 = RestaurantReceipt(groupNumber: 2, items: [
            RestaurantMenu(name: "Tea", price: 3, quantity: 1),
            RestaurantMenu(name: "Coffee", price: 3, quantity: 3),
            RestaurantMenu(name: "Soda", price: 4, quantity: 1),
            RestaurantMenu(name: "Big Brekkie", price: 16, quantity: 3),
            RestaurantMenu(name: "Poached Eggs", price: 12, quantity: 1),
            RestaurantMenu(name: "Garden Salad", price: 10, quantity: 1)
        ])
        
        let group3 = RestaurantReceipt(groupNumber: 3, items: [
            RestaurantMenu(name: "Tea", price: 3, quantity: 2),
            RestaurantMenu(name: "Coffee", price: 3, quantity: 3),
            RestaurantMenu(name: "Soda", price: 4, quantity: 2),
            RestaurantMenu(name: "Bruchetta", price: 8, quantity: 5),
            RestaurantMenu(name: "Big Brekkie", price: 16, quantity: 5),
            RestaurantMenu(name: "Poached Eggs", price: 12, quantity: 2),
            RestaurantMenu(name: "Garden Salad", price: 10, quantity: 3)
        ])
        
        let (_, _, remaining1) = paymentCalculation(for: group1)
        XCTAssertEqual(remaining1, 0.0)
        
        let (_, _, remaining2) = paymentCalculation(for: group2, discount: 0.1, creditCardPayment: true)
        XCTAssertEqual(remaining2, 0.0)
        
        let (_, _, remaining3) = paymentCalculation(for: group3, discount: 0.25)
        XCTAssertEqual(remaining3, 0.0)
    }
}

let testSuite = RestaurantTests()
testSuite.testHandlePayment()
