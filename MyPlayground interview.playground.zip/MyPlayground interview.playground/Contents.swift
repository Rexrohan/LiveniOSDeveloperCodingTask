import UIKit

struct RestaurantMenu {
    let name: String
    let price: Double
}

struct RestaurantReceipt {
    var items: [RestaurantMenu]
    var groupNumber: Int
    var discount: Double
    var initialTab: Double
    var isCreditCardPayment: Bool

    func calculateTotalAmount() -> Double {
        let subtotal = items.reduce(0) { $0 + $1.price }
        var total = subtotal

        total -= discount

        if isCreditCardPayment {
            total += total * 0.012
        }

        return total
    }

    func displayInvoice() {
        print("Group \(groupNumber) Invoice:")
        for item in items {
            print("\(item.name) $\(item.price)")
        }

        let subtotal = items.reduce(0) { $0 + $1.price }
        print("Subtotal: $\(subtotal)")

        if discount > 0 {
            print("Discount: -$\(discount)")
        }

        if isCreditCardPayment {
            let surcharge = subtotal * 0.012
            print("Credit Card Surcharge: +$\(surcharge)")
        }

        let total = calculateTotalAmount()
        print("Total: $\(total)")

        print("\nPayment Details:")
        let numberOfPeople = items.count
        let amountPerPerson = total / Double(numberOfPeople)

        for _ in 1...numberOfPeople {
            print("Paid $\(amountPerPerson)")
        }
    }
}

let menu = [
    RestaurantMenu(name: "Big Brekkie", price: 16),
    RestaurantMenu(name: "Bruchetta", price: 8),
    RestaurantMenu(name: "Poached Eggs", price: 12),
    RestaurantMenu(name: "Coffee", price: 5),
    RestaurantMenu(name: "Tea", price: 3),
    RestaurantMenu(name: "Soda", price: 4),
    RestaurantMenu(name: "Garden Salad", price: 10)
]

let group1 = RestaurantReceipt(items: [menu[0], menu[0], menu[1], menu[2], menu[4], menu[5], menu[6]],
                            groupNumber: 1,
                            discount: 0,
                            initialTab: 0,
                            isCreditCardPayment: false)
group1.displayInvoice()

let group2 = RestaurantReceipt(items: [menu[4], menu[3], menu[5], menu[0], menu[2], menu[6], menu[6]],
                            groupNumber: 2,
                            discount: 0.1,
                            initialTab: 0,
                            isCreditCardPayment: true)
group2.displayInvoice()

let group3 = RestaurantReceipt(items: [menu[4], menu[3], menu[5], menu[0], menu[1], menu[2], menu[6], menu[0], menu[2], menu[6], menu[0], menu[2], menu[6], menu[0], menu[2], menu[6], menu[0], menu[2], menu[6]],
                            groupNumber: 3,
                            discount: 25,
                            initialTab: 50,
                            isCreditCardPayment: false)
group3.displayInvoice()

